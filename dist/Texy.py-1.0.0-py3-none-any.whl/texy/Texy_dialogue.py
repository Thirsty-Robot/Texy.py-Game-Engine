def multiple_dialog(array):
	for i in array:
		print (i)

def announcement (string_to_output):
	print ('Announcement: %s' % (string_to_output))