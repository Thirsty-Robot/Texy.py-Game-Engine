import os
import sys

def move_scene(room_to_move):
	os.system('python '+room_to_move)
	sys.exit()